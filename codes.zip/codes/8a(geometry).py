def squareArea( side ): 
    area = side * side 
    return area

def circleArea(r): 
    PI = 3.1412
    return PI * (r*r)
